## intent:ask_restaurant
- Can you suggest some good restaurants in [Rishikesh](location)
- Okay. Show me some in [Allahabad](location)
- Ill prefer chines

## intent:ask_budget
- >700
