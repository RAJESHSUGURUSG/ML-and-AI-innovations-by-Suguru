
## interactive_story_1
* greet
