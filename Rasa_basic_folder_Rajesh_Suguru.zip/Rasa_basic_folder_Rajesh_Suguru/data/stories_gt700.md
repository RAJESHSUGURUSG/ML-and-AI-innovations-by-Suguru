
## interactive_story_1
* ask_restaurant{"location": "Rishikesh"}
    - slot{"location": "Rishikesh"}
    - action_location_valid
    - slot{"location_validity": "invalid"}
    - utter_location_invalid
    - utter_ask_location_retry
* ask_restaurant{"location": "Allahabad"}
    - slot{"location": "Allahabad"}
    - action_location_valid
    - slot{"location_validity": "valid"}
    - utter_ask_cuisine
* ask_restaurant
    - utter_ask_budget
* ask_budget
    - action_restaurant
    - slot{"search_validity": "valid"}
    - slot{"email_message": "rajesh.suguru.sg@gmail.com\n   1. Barbeque Nation in Fifth Floor, P Square Mall, MG Road, George Town, Allahabad has been rated 4.9 out of 5. Average cost for 2 : 1200\n\n   2. Sagar Ratna in 3/3, Hashimpur Road, Balson Crossing, Near Anand Bhawan, Tagore Town, Allahabad has been rated 4.5 out of 5. Average cost for 2 : 800\n\n   3. Old School Cafe in 2nd Floor, 9-10 Tulsiani Grace, Civil Lines, Allahabad has been rated 4.5 out of 5. Average cost for 2 : 1000\n\n   4. Allahabad Kabab Paratha in 5A, Atala, Kareli, Allahabad has been rated 4.4 out of 5. Average cost for 2 : 600\n\n   5. Pind Balluchi in 48/8, Stratchy Road, Civil Lines, Allahabad has been rated 4.4 out of 5. Average cost for 2 : 1000\n\n   6. EDEN by Connoisseur in Hotel Samrat, Civil Lines, Allahabad has been rated 4.4 out of 5. Average cost for 2 : 1000\n\n   7. El Chico Restaurant in 142A, 32, Mahatma Gandhi, Civil Lines, Allahabad has been rated 4.4 out of 5. Average cost for 2 : 800\n\n   8. SCORE - The Games Cafe in 138 C/30, M.G. Marg Civil Lines, Behind Bank of Baroda, Near Subhash Crossing, Civil Lines, Allahabad has been rated 4.4 out of 5. Average cost for 2 : 200\n\n   9. Aharam in 23/47/121 T, bajrang nagar, allahpur, allahabad, Allapur, Allahabad has been rated 4.4 out of 5. Average cost for 2 : 300\n\n   10. 34 Stairs in 23/47/159, Shiv Nagar, Allapur, Allahabad has been rated 4.4 out of 5. Average cost for 2 : 300\n"}
    - utter_ask_details
