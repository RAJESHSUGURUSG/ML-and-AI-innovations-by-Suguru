## intent:greet
- Hi
- Hola

## intent:ask_restaurant
- Find restaurants
