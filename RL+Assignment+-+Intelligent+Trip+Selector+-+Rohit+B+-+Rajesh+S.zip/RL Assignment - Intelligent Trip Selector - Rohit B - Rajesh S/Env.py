# Deep Reinforcement Learning Project by Rohit Bhalerao and Rajesh Suguru
# Choosing the right requests to maximize the profits for the cab drivers (rewards)
# Simulation of the Environment for the Cab Driver Agent 
# Import routines

import numpy as np
import math
import random
from itertools import permutations


# Defining hyperparameters
m = 5 # number of cities, ranges from 1 ..... m
t = 24 # number of hours, ranges from 0 .... t-1
d = 7  # number of days, ranges from 0 ... d-1
C = 5 # Per hour fuel and other costs
R = 9 # per hour revenue from a passenger


class CabDriver():

    def __init__(self):
        """initialise your state and define your action space and state space"""
        self.action_space = [(0, 0)] + \
            list(permutations([i for i in range(m)], 2))
        self.state_space = [[a, b, c]
                            for a in range(m) for b in range(t) for c in range(d)]
        self.state_init = random.choice(self.state_space)
        # Start the first round
        self.reset()
       

    ## Encoding state (or state-action) for NN input

    def state_encod_arch1(self, state):
        """convert the state into a vector so that it can be fed to the NN. This method converts a given state into a vector format. Hint: The vector is of size m + t + d."""

        state_encoded_vector = [0 for _ in range(m+t+d)]
        state_encoded_vector[self.state_get_location(state)] = 1
        state_encoded_vector[m+self.state_get_time(state)] = 1
        state_encoded_vector[m+t+self.state_get_day(state)] = 1
        return state_encoded_vector

    ## Getting number of requests

    ## Referring to MDP.pdf provided
    ## Location λ (of Poisson Distribution)
    ## Location A 2
    ## Location B 12
    ## Location C 4
    ## Location D 7
    ## Location E 8
    ## USe these numbers in the location 1,2,3,4
    
    def requests(self, state):
        """Determining the number of requests basis the location. 
        Use the table specified in the MDP and complete for rest of the locations"""
        location = state[0]
        if location == 0:
            requests = np.random.poisson(2)
        if location == 1:
            requests = np.random.poisson(12)
        if location == 2:
            requests = np.random.poisson(4)
        if location == 3:
            requests = np.random.poisson(7)
        if location == 4:
            requests = np.random.poisson(8)


        if requests >15:
            requests =15

            
       ##     Referring to MDP.pdf 
       ##     There’ll never be requests of the sort where pickup and drop locations are the same. So, the action
       ##     space A will be: (𝑚 − 1) ∗ 𝑚 + 1 for m locations. 
       ##     (0, 0) tuple represents ’no-ride’ action. Not considered
    
        possible_actions_index = random.sample(range(1, (m-1)*m +1), requests)+ [0] # (0,0) is not considered as customer request
        actions = [self.action_space[i] for i in possible_actions_index]
        return possible_actions_index,actions   

    
    
    def update_time_day(self, time, day, cab_ride_duration):
        """
        Consideres current state, time taken to return and accordingly calculates the day and time
        """
        cab_ride_duration = int(cab_ride_duration)
        
        ## If the final hours are less than 24, the time is still in the same day
        if (time + cab_ride_duration) < 24:
            time = time + cab_ride_duration 
        else:
            ## If the final hours are equal or more than 24, the time is in the next day & needs conversion to 0-23 scale
            time = (time + cab_ride_duration) % 24 
            
            # calculate number of days and convert to 0 to 6 range
            num_days = (time + cab_ride_duration) // 24
            day = (day + num_days ) % 7

        return time, day


    def reward_func(self, wait_time, transit_time, ride_time):
        """Takes in state, action and Time-matrix and returns the reward"""
        # Passenger time results in revenue
        # Transit time to go from one location to other and also, wait time give no revenue. Consider as idle times
        passenger_time = ride_time
        idle_time = wait_time + transit_time
        reward = (R * passenger_time) - (C * (passenger_time + idle_time))
        return reward

    ## functions to get and set state and action variables

    def state_get_location(self, state):
        return state[0]

    def state_get_time(self, state):
        return state[1]

    def state_get_day(self, state):
        return state[2]

    def action_get_pickup(self, action):
        return action[0]

    def action_get_drop(self, action):
        return action[1]

    def next_state_func(self, state, action, Time_matrix):
        """Takes state and action as input and returns next state"""
        next_state = []
        
        # Initialize time variables
        total_time   = 0    # Initialize to zero
        transit_time = 0    # To travel from current to pick-up location
        wait_time    = 0    # Driver chooses to refuse all requests
        ride_time    = 0    # To travel with passenger from pick-up location to drop location
        
        # Get the current location, time, day and request locations
        current_location = self.state_get_location(state)
        pickup_location = self.action_get_pickup(action)
        drop_location = self.action_get_drop(action)
        current_time = self.state_get_time(state)
        current_day = self.state_get_day(state)
        
        """
           There are three(3) situations: 
           1) Driver refuses all requests - pickup_location and drop location = 0 
           2) Driver is at pickup location (current location = pickup location)
           3) Driver is not at the pickup location (current location = pickup location)
        """

        if ((pickup_location== 0) and (drop_location == 0)):
            # Situation 1 
            # Refuse all requests, wait time is 1, next location doesn't change and so, its current location
            wait_time = 1
            next_location = current_location
        elif (current_location == pickup_location):
            # Situation 2 
            # Driver is at pickup locaion. Wait time and transit time both are 0. next location is drop location
            ride_time = Time_matrix[current_location][drop_location][current_time][current_day]
            next_location = drop_location
        else:
            # Situation 3 
            # Driver is not at pickup locaion. So, the driver has to travel to pickup point
            # Time taken to reach pickup point is the transit time
            transit_time      = Time_matrix[current_location][pickup_location][current_time][current_day]
            new_time, new_day = self.update_time_day(current_time, current_day, transit_time)
            
            # The driver reaches pickup location , picks up the passenger and drops him to the destimation
            ride_time = Time_matrix[pickup_location][drop_location][new_time][new_day]
            next_location  = drop_location

        # Calculate total time as sum of all times - wait, transit and ride time
        total_time = (wait_time + transit_time + ride_time)
        next_time, next_day = self.update_time_day(current_time, current_day, total_time)
        
        # The next_state is next_location and the new time and day state
        next_state = [next_location, next_time, next_day]
        
        return next_state, wait_time, transit_time, ride_time

    
    
    def step(self, state, action, Time_matrix):
        """
        Method to simulate a trip to get rewards, reach next step which consumes time 
        """
        # Get the next state and the various time durations
        next_state, wait_time, transit_time, ride_time = self.next_state_func(state, action, Time_matrix)

        # Calculate the reward based on the different time durations
        rewards = self.reward_func(wait_time, transit_time, ride_time)
        total_time = wait_time + transit_time + ride_time
        
        return rewards, next_state, total_time



    def reset(self):
        return self.action_space, self.state_space, self.state_init
